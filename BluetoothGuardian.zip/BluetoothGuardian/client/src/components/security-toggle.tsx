import { useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { LucideIcon } from 'lucide-react';

interface SecurityToggleProps {
  icon: LucideIcon;
  title: string;
  description: string;
  enabled: boolean;
  onToggle: (enabled: boolean) => void;
  color: string;
  status?: string;
}

export function SecurityToggle({
  icon: Icon,
  title,
  description,
  enabled,
  onToggle,
  color,
  status
}: SecurityToggleProps) {
  const [isToggling, setIsToggling] = useState(false);

  const handleToggle = async (checked: boolean) => {
    setIsToggling(true);
    try {
      await onToggle(checked);
    } finally {
      setIsToggling(false);
    }
  };

  const getStatusColor = () => {
    if (!enabled) return 'bg-accent/20 text-accent';
    return 'bg-secondary/20 text-secondary';
  };

  const getStatusText = () => {
    if (!enabled) return 'Inactive';
    return status || 'Active';
  };

  return (
    <div className={`bg-surface rounded-xl p-4 shadow-lg transition-all duration-200 ${
      enabled ? 'ring-2 ring-primary/20' : ''
    }`}>
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center`} 
             style={{ backgroundColor: `${color}20` }}>
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <Switch
          checked={enabled}
          onCheckedChange={handleToggle}
          disabled={isToggling}
          className="data-[state=checked]:bg-secondary"
        />
      </div>
      
      <div className="space-y-2">
        <h3 className="font-semibold text-white text-sm">{title}</h3>
        <p className="text-xs text-gray-400">{description}</p>
        <Badge variant="secondary" className={`text-xs px-2 py-1 ${getStatusColor()}`}>
          {getStatusText()}
        </Badge>
      </div>
    </div>
  );
}

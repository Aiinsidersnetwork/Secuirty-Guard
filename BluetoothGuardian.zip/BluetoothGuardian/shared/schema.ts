import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const securitySettings = pgTable("security_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  bluetoothEnabled: boolean("bluetooth_enabled").default(true),
  quantumEncryptionEnabled: boolean("quantum_encryption_enabled").default(false),
  locationPrivacyEnabled: boolean("location_privacy_enabled").default(true),
  mockLatitude: text("mock_latitude").default("37.7749"),
  mockLongitude: text("mock_longitude").default("-122.4194"),
  lastBackupTime: timestamp("last_backup_time").defaultNow(),
});

export const backupHistory = pgTable("backup_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  timestamp: timestamp("timestamp").defaultNow(),
  backupType: text("backup_type").notNull(), // 'full', 'contacts', 'sms', etc.
  encryptedData: text("encrypted_data"),
  size: text("size"),
  itemCount: integer("item_count"),
  encryptionMethod: text("encryption_method").default("Kyber-768"),
});

export const encryptedFiles = pgTable("encrypted_files", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  fileName: text("file_name").notNull(),
  originalSize: text("original_size"),
  encryptedData: text("encrypted_data").notNull(),
  encryptionMethod: text("encryption_method").default("Kyber-768"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cryptographicKeys = pgTable("cryptographic_keys", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  publicKey: text("public_key").notNull(),
  encryptedPrivateKey: text("encrypted_private_key").notNull(),
  keyType: text("key_type").notNull(), // 'kyber', 'aes', 'hybrid'
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSecuritySettingsSchema = createInsertSchema(securitySettings).omit({
  id: true,
  userId: true,
});

export const insertBackupHistorySchema = createInsertSchema(backupHistory).omit({
  id: true,
  userId: true,
  timestamp: true,
});

export const insertEncryptedFilesSchema = createInsertSchema(encryptedFiles).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertCryptographicKeysSchema = createInsertSchema(cryptographicKeys).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type SecuritySettings = typeof securitySettings.$inferSelect;
export type InsertSecuritySettings = z.infer<typeof insertSecuritySettingsSchema>;
export type BackupHistory = typeof backupHistory.$inferSelect;
export type InsertBackupHistory = z.infer<typeof insertBackupHistorySchema>;
export type EncryptedFiles = typeof encryptedFiles.$inferSelect;
export type InsertEncryptedFiles = z.infer<typeof insertEncryptedFilesSchema>;
export type CryptographicKeys = typeof cryptographicKeys.$inferSelect;
export type InsertCryptographicKeys = z.infer<typeof insertCryptographicKeysSchema>;

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useTimer, formatTimestamp } from '@/hooks/use-timer';
import { CloudUpload, History, ChevronDown } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { SecuritySettings } from '@shared/schema';

interface BackupTimerProps {
  onViewMoreToggle: () => void;
  isViewMoreOpen: boolean;
}

export function BackupTimer({ onViewMoreToggle, isViewMoreOpen }: BackupTimerProps) {
  const [isBackingUp, setIsBackingUp] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings } = useQuery<SecuritySettings>({
    queryKey: ['/api/security-settings']
  });

  const lastBackupTime = settings?.lastBackupTime ? new Date(settings.lastBackupTime) : new Date();
  const timer = useTimer(lastBackupTime);

  const backupMutation = useMutation({
    mutationFn: async () => {
      setIsBackingUp(true);
      // Simulate encryption process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return apiRequest('POST', '/api/backup', {
        backupType: 'manual',
        encryptedData: `encrypted_backup_${Date.now()}`,
        size: `${Math.floor(Math.random() * 100 + 200)} MB`,
        itemCount: Math.floor(Math.random() * 500 + 100)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/backup-history'] });
      toast({
        title: "Backup Complete",
        description: "Your data has been encrypted and backed up securely.",
      });
    },
    onError: () => {
      toast({
        title: "Backup Failed",
        description: "Failed to create encrypted backup. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsBackingUp(false);
    }
  });

  const handleBackup = () => {
    backupMutation.mutate();
  };

  // Calculate progress for circular timer (max 72 hours)
  const maxHours = 72;
  const progress = Math.min((timer.hours / maxHours) * 360, 360);

  return (
    <section className="px-4 py-8 text-center bg-surface mx-4 mt-6 rounded-xl shadow-lg">
      <h2 className="text-lg font-semibold mb-6 text-gray-200">Time Since Last Backup</h2>
      
      {/* Circular Timer Display */}
      <div className="relative w-32 h-32 mx-auto mb-6">
        <div 
          className="w-full h-full rounded-full flex items-center justify-center transition-all duration-1000"
          style={{
            background: `conic-gradient(from 0deg, #1565C0 0deg ${progress}deg, #1E1E1E ${progress}deg 360deg)`
          }}
        >
          <div className="bg-surface w-24 h-24 rounded-full flex flex-col items-center justify-center">
            <span className="text-2xl font-bold text-white">{timer.hours}</span>
            <span className="text-xs text-gray-400">HOURS</span>
          </div>
        </div>
      </div>

      {/* Timer Details */}
      <div className="mb-6">
        <div className="text-sm text-gray-400 mb-1">Last backup</div>
        <div className="font-mono text-gray-300">
          {formatTimestamp(lastBackupTime)}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-3">
        <Button 
          onClick={handleBackup}
          disabled={isBackingUp || backupMutation.isPending}
          className="flex-1 bg-primary hover:bg-blue-700 text-white font-semibold py-3 px-4 relative overflow-hidden"
        >
          <CloudUpload className="w-4 h-4 mr-2" />
          <span>{isBackingUp ? 'Encrypting...' : 'Backup Now'}</span>
        </Button>
        
        <Button 
          onClick={onViewMoreToggle}
          variant="secondary"
          className="bg-gray-600 hover:bg-gray-500 text-white font-semibold py-3 px-4"
        >
          <History className="w-4 h-4 mr-2" />
          <span>View More</span>
          <ChevronDown 
            className={`w-4 h-4 ml-2 transition-transform duration-200 ${
              isViewMoreOpen ? 'rotate-180' : ''
            }`} 
          />
        </Button>
      </div>
    </section>
  );
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSecuritySettingsSchema, insertBackupHistorySchema, insertEncryptedFilesSchema, insertCryptographicKeysSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const DEFAULT_USER_ID = 1; // For demo purposes, using a default user

  // Get security settings
  app.get("/api/security-settings", async (req, res) => {
    try {
      const settings = await storage.getSecuritySettings(DEFAULT_USER_ID);
      if (!settings) {
        return res.status(404).json({ message: "Security settings not found" });
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch security settings" });
    }
  });

  // Update security settings
  app.patch("/api/security-settings", async (req, res) => {
    try {
      const validatedData = insertSecuritySettingsSchema.partial().parse(req.body);
      const updatedSettings = await storage.updateSecuritySettings(DEFAULT_USER_ID, validatedData);
      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update security settings" });
    }
  });

  // Reset timer (create new backup)
  app.post("/api/backup", async (req, res) => {
    try {
      const { encryptedData, size, backupType, itemCount } = req.body;
      
      const backupData = {
        backupType: backupType || "manual",
        encryptedData: encryptedData || "encrypted_backup_data_placeholder",
        size: size || "247 MB",
        itemCount: itemCount || null,
        encryptionMethod: "Kyber-768"
      };

      const validatedData = insertBackupHistorySchema.parse(backupData);
      const newBackup = await storage.createBackupEntry(DEFAULT_USER_ID, validatedData);
      
      // Update last backup time in settings
      await storage.updateSecuritySettings(DEFAULT_USER_ID, {
        lastBackupTime: new Date()
      });

      res.json(newBackup);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid backup data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create backup" });
    }
  });

  // Get backup history
  app.get("/api/backup-history", async (req, res) => {
    try {
      const history = await storage.getBackupHistory(DEFAULT_USER_ID);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch backup history" });
    }
  });

  // Delete specific backup
  app.delete("/api/backup-history/:id", async (req, res) => {
    try {
      const backupId = parseInt(req.params.id);
      if (isNaN(backupId)) {
        return res.status(400).json({ message: "Invalid backup ID" });
      }

      const deleted = await storage.deleteBackupEntry(DEFAULT_USER_ID, backupId);
      if (!deleted) {
        return res.status(404).json({ message: "Backup not found" });
      }

      res.json({ message: "Backup deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete backup" });
    }
  });

  // Clear all backup history
  app.delete("/api/backup-history", async (req, res) => {
    try {
      await storage.clearBackupHistory(DEFAULT_USER_ID);
      res.json({ message: "All backup history cleared" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear backup history" });
    }
  });

  // Generate cryptographic keys
  app.post("/api/crypto/generate-keys", async (req, res) => {
    try {
      const { keyType } = req.body;
      
      if (!keyType || !['kyber', 'aes', 'hybrid'].includes(keyType)) {
        return res.status(400).json({ message: "Invalid key type. Must be 'kyber', 'aes', or 'hybrid'" });
      }

      // Simulate key generation
      const keyData = {
        publicKey: `${keyType}_public_key_${Date.now()}`,
        encryptedPrivateKey: `encrypted_${keyType}_private_key_${Date.now()}`,
        keyType
      };

      const validatedData = insertCryptographicKeysSchema.parse(keyData);
      const newKey = await storage.createCryptographicKey(DEFAULT_USER_ID, validatedData);

      res.json(newKey);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid key data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to generate keys" });
    }
  });

  // Get cryptographic keys
  app.get("/api/crypto/keys", async (req, res) => {
    try {
      const keyType = req.query.type as string;
      const keys = await storage.getCryptographicKeys(DEFAULT_USER_ID, keyType);
      res.json(keys);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cryptographic keys" });
    }
  });

  // File encryption endpoints
  app.post("/api/encrypt-file", async (req, res) => {
    try {
      const { fileName, fileData, originalSize } = req.body;
      
      if (!fileName || !fileData) {
        return res.status(400).json({ message: "File name and data are required" });
      }

      // Simulate Kyber encryption
      const encryptedData = `kyber_encrypted_${Buffer.from(fileData).toString('base64')}`;
      
      const fileEntry = {
        fileName,
        originalSize: originalSize || "Unknown",
        encryptedData,
        encryptionMethod: "Kyber-768"
      };

      const validatedData = insertEncryptedFilesSchema.parse(fileEntry);
      const newFile = await storage.createEncryptedFile(DEFAULT_USER_ID, validatedData);

      res.json(newFile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid file data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to encrypt file" });
    }
  });

  // Get encrypted files
  app.get("/api/encrypted-files", async (req, res) => {
    try {
      const files = await storage.getEncryptedFiles(DEFAULT_USER_ID);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch encrypted files" });
    }
  });

  // Delete encrypted file
  app.delete("/api/encrypted-files/:id", async (req, res) => {
    try {
      const fileId = parseInt(req.params.id);
      if (isNaN(fileId)) {
        return res.status(400).json({ message: "Invalid file ID" });
      }

      const deleted = await storage.deleteEncryptedFile(DEFAULT_USER_ID, fileId);
      if (!deleted) {
        return res.status(404).json({ message: "File not found" });
      }

      res.json({ message: "File deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Update location coordinates
  app.patch("/api/location", async (req, res) => {
    try {
      const { latitude, longitude } = req.body;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }

      const updatedSettings = await storage.updateSecuritySettings(DEFAULT_USER_ID, {
        mockLatitude: latitude.toString(),
        mockLongitude: longitude.toString()
      });

      res.json(updatedSettings);
    } catch (error) {
      res.status(500).json({ message: "Failed to update location" });
    }
  });

  // Reset all settings
  app.post("/api/reset", async (req, res) => {
    try {
      // Reset security settings to defaults
      const defaultSettings = {
        bluetoothEnabled: true,
        quantumEncryptionEnabled: false,
        locationPrivacyEnabled: true,
        mockLatitude: "37.7749",
        mockLongitude: "-122.4194",
        lastBackupTime: new Date()
      };

      await storage.updateSecuritySettings(DEFAULT_USER_ID, defaultSettings);
      await storage.clearBackupHistory(DEFAULT_USER_ID);

      res.json({ message: "All settings reset successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reset settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

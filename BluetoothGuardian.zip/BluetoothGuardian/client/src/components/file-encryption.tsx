import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Upload, File, Trash2, Download, Lock } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { formatTimestampShort } from '@/hooks/use-timer';
import type { EncryptedFiles } from '@shared/schema';

export function FileEncryption() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isEncrypting, setIsEncrypting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: encryptedFiles = [] } = useQuery<EncryptedFiles[]>({
    queryKey: ['/api/encrypted-files']
  });

  const encryptFileMutation = useMutation({
    mutationFn: async (file: File) => {
      setIsEncrypting(true);
      
      // Read file as base64
      const fileData = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });

      // Simulate encryption time
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      return apiRequest('POST', '/api/encrypt-file', {
        fileName: file.name,
        fileData: fileData.split(',')[1], // Remove data URL prefix
        originalSize: `${(file.size / 1024 / 1024).toFixed(2)} MB`
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/encrypted-files'] });
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      toast({
        title: "File Encrypted",
        description: "Your file has been encrypted with Kyber post-quantum cryptography.",
      });
    },
    onError: () => {
      toast({
        title: "Encryption Failed",
        description: "Failed to encrypt file. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsEncrypting(false);
    }
  });

  const deleteFileMutation = useMutation({
    mutationFn: (fileId: number) => apiRequest('DELETE', `/api/encrypted-files/${fileId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/encrypted-files'] });
      toast({
        title: "File Deleted",
        description: "The encrypted file has been permanently deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete file. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (limit to 10MB for demo)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select a file smaller than 10MB.",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleEncrypt = () => {
    if (selectedFile) {
      encryptFileMutation.mutate(selectedFile);
    }
  };

  const formatFileSize = (sizeStr: string) => {
    return sizeStr || "Unknown size";
  };

  return (
    <div className="space-y-6">
      {/* File Upload Section */}
      <Card className="bg-surface border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Lock className="w-5 h-5 mr-2 text-warning" />
            Kyber File Encryption
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="file-upload" className="text-gray-300">Select File to Encrypt</Label>
            <Input
              id="file-upload"
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="mt-2 bg-gray-700 border-gray-600 text-white file:bg-primary file:text-white file:border-0 file:rounded file:px-3 file:py-1"
              disabled={isEncrypting}
            />
          </div>

          {selectedFile && (
            <div className="p-3 bg-gray-700/30 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <File className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-white font-medium">{selectedFile.name}</p>
                    <p className="text-gray-400 text-sm">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <Button
                  onClick={handleEncrypt}
                  disabled={isEncrypting}
                  className="bg-warning hover:bg-yellow-600 text-black font-semibold"
                >
                  {isEncrypting ? 'Encrypting...' : 'Encrypt with Kyber'}
                </Button>
              </div>
            </div>
          )}

          <div className="flex items-center space-x-2 text-sm text-gray-400">
            <Lock className="w-4 h-4" />
            <span>Files are encrypted using Kyber-768 post-quantum cryptography</span>
          </div>
        </CardContent>
      </Card>

      {/* Encrypted Files List */}
      <Card className="bg-surface border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Encrypted Files</CardTitle>
        </CardHeader>
        <CardContent>
          {encryptedFiles.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-700/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <File className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400 text-sm">No encrypted files yet</p>
              <p className="text-gray-500 text-xs mt-1">Encrypt your first file to see it here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {encryptedFiles.map((file) => (
                <div key={file.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <File className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-white font-medium">{file.fileName}</p>
                      <div className="flex items-center space-x-2 text-xs text-gray-400">
                        <span>{formatFileSize(file.originalSize!)}</span>
                        <span>•</span>
                        <span>{formatTimestampShort(new Date(file.createdAt!))}</span>
                        <Badge variant="secondary" className="bg-warning/20 text-warning ml-2">
                          {file.encryptionMethod}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-400 hover:text-accent hover:bg-red-500/10 p-2"
                      onClick={() => deleteFileMutation.mutate(file.id)}
                      disabled={deleteFileMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
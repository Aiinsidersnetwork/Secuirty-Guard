import { Button } from '@/components/ui/button';
import { ConfirmationDialog } from '@/components/ui/confirmation-dialog';
import { History, Trash2, Trash } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { formatTimestampShort } from '@/hooks/use-timer';
import type { BackupHistory } from '@shared/schema';

interface BackupHistoryProps {
  isOpen: boolean;
}

export function BackupHistory({ isOpen }: BackupHistoryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: backupHistory = [] } = useQuery<BackupHistory[]>({
    queryKey: ['/api/backup-history']
  });

  const deleteBackupMutation = useMutation({
    mutationFn: (backupId: number) => apiRequest('DELETE', `/api/backup-history/${backupId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/backup-history'] });
      toast({
        title: "Backup Deleted",
        description: "The encrypted backup has been permanently deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete backup. Please try again.",
        variant: "destructive",
      });
    }
  });

  const clearAllMutation = useMutation({
    mutationFn: () => apiRequest('DELETE', '/api/backup-history'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/backup-history'] });
      toast({
        title: "History Cleared",
        description: "All backup history has been cleared.",
      });
    },
    onError: () => {
      toast({
        title: "Clear Failed",
        description: "Failed to clear backup history. Please try again.",
        variant: "destructive",
      });
    }
  });

  if (!isOpen) return null;

  return (
    <section className="px-4 pb-8 animate-slide-down">
      <div className="bg-surface rounded-xl p-4 shadow-lg">
        <h3 className="font-semibold text-white mb-4 flex items-center">
          <History className="w-4 h-4 mr-2 text-primary" />
          Backup History
        </h3>
        
        {backupHistory.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gray-700/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <History className="w-8 h-8 text-gray-500" />
            </div>
            <p className="text-gray-400 text-sm">No backup history available</p>
            <p className="text-gray-500 text-xs mt-1">Create your first backup to see it here</p>
          </div>
        ) : (
          <div className="space-y-3">
            {backupHistory.map((backup) => (
              <div key={backup.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                <div>
                  <div className="font-mono text-sm text-white">
                    {formatTimestampShort(new Date(backup.timestamp!))}
                  </div>
                  <div className="text-xs text-gray-400">
                    {backup.backupType} • {backup.encryptionMethod} • {backup.size}
                    {backup.itemCount && ` • ${backup.itemCount} items`}
                  </div>
                </div>
                <ConfirmationDialog
                  title="Delete Backup"
                  description="This will permanently delete the encrypted backup. This action cannot be undone."
                  onConfirm={() => deleteBackupMutation.mutate(backup.id)}
                  destructive
                  confirmText="Delete"
                  trigger={
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-400 hover:text-accent hover:bg-red-500/10 p-2"
                      disabled={deleteBackupMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  }
                />
              </div>
            ))}
            
            {backupHistory.length > 0 && (
              <ConfirmationDialog
                title="Clear All History"
                description="This will permanently delete all backup history. This action cannot be undone."
                onConfirm={() => clearAllMutation.mutate()}
                destructive
                confirmText="Clear All"
                trigger={
                  <Button
                    variant="ghost"
                    className="w-full mt-4 text-sm text-gray-400 hover:text-gray-300 hover:bg-gray-700/50"
                    disabled={clearAllMutation.isPending}
                  >
                    <Trash className="w-4 h-4 mr-2" />
                    Clear All History
                  </Button>
                }
              />
            )}
          </div>
        )}
      </div>
    </section>
  );
}

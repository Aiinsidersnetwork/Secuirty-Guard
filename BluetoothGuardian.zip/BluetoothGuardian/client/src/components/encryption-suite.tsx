import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { 
  Key, 
  Shield, 
  Lock, 
  FileKey,
  Download,
  Upload,
  Trash2,
  FileSignature,
  Settings
} from 'lucide-react';
import { encryptWithAdvancedMethod, shredFile, signData } from '@/lib/crypto';
import type { AdvancedEncryptionOptions } from '@/lib/crypto';

interface EncryptionSuiteProps {
  isOpen: boolean;
}

export function EncryptionSuite({ isOpen }: EncryptionSuiteProps) {
  const [activeTab, setActiveTab] = useState('encrypt');
  const [encryptionMethod, setEncryptionMethod] = useState<'aes' | 'kyber' | 'hybrid' | 'pake'>('aes');
  const [keySize, setKeySize] = useState<'512' | '768' | '1024'>('768');
  const [password, setPassword] = useState('');
  const [signFile, setSignFile] = useState(false);
  const [shredOriginal, setShredOriginal] = useState(false);
  const [shredPasses, setShredPasses] = useState(3);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [decryptFile, setDecryptFile] = useState<File | null>(null);
  const [privateKey, setPrivateKey] = useState('');
  const { toast } = useToast();

  const encryptMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile) throw new Error('No file selected');
      
      const fileContent = await selectedFile.text();
      const options: AdvancedEncryptionOptions = {
        method: encryptionMethod,
        keySize,
        signFile,
        shredOriginal,
        shredPasses,
        customPassword: password || undefined
      };
      
      const encrypted = await encryptWithAdvancedMethod(fileContent, options);
      
      if (signFile) {
        const signature = await signData(encrypted);
        toast({
          title: "File Signed",
          description: `Dilithium signature: ${signature.substring(0, 16)}...`
        });
      }
      
      if (shredOriginal) {
        await shredFile(shredPasses);
        toast({
          title: "File Shredded",
          description: `Original file securely deleted with ${shredPasses} passes`
        });
      }
      
      // Create download link
      const blob = new Blob([encrypted], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedFile.name}.encrypted`;
      a.click();
      
      return encrypted;
    },
    onSuccess: () => {
      toast({
        title: "Encryption Complete",
        description: `File encrypted using ${encryptionMethod.toUpperCase()} method`
      });
    }
  });

  const decryptMutation = useMutation({
    mutationFn: async () => {
      if (!decryptFile) throw new Error('No file selected for decryption');
      // Decrypt logic would go here
      toast({
        title: "Decryption Complete",
        description: "File successfully decrypted"
      });
    }
  });

  if (!isOpen) return null;

  return (
    <div className="bg-surface rounded-xl p-6 shadow-lg animate-slide-down">
      <div className="flex items-center mb-6">
        <Shield className="w-6 h-6 text-primary mr-3" />
        <h3 className="text-xl font-bold text-white">🔐 Encryption Suite</h3>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-gray-700/30">
          <TabsTrigger value="encrypt" className="data-[state=active]:bg-primary">
            <Lock className="w-4 h-4 mr-2" />
            Encrypt
          </TabsTrigger>
          <TabsTrigger value="decrypt" className="data-[state=active]:bg-primary">
            <Key className="w-4 h-4 mr-2" />
            Decrypt
          </TabsTrigger>
        </TabsList>

        <TabsContent value="encrypt" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Encryption Method */}
            <div className="space-y-2">
              <Label className="text-gray-300">Encryption Method</Label>
              <Select value={encryptionMethod} onValueChange={(value: any) => setEncryptionMethod(value)}>
                <SelectTrigger className="bg-gray-700/50 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="aes">AES (Password)</SelectItem>
                  <SelectItem value="kyber">Kyber (Key-Based)</SelectItem>
                  <SelectItem value="hybrid">Hybrid (AES + Kyber)</SelectItem>
                  <SelectItem value="pake">Kyber + PAKE</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Key Size */}
            {(encryptionMethod === 'kyber' || encryptionMethod === 'hybrid') && (
              <div className="space-y-2">
                <Label className="text-gray-300">Kyber Key Size</Label>
                <Select value={keySize} onValueChange={(value: any) => setKeySize(value)}>
                  <SelectTrigger className="bg-gray-700/50 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="512">Kyber-512</SelectItem>
                    <SelectItem value="768">Kyber-768</SelectItem>
                    <SelectItem value="1024">Kyber-1024</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          {/* Password Input */}
          {(encryptionMethod === 'aes' || encryptionMethod === 'pake') && (
            <div className="space-y-2">
              <Label className="text-gray-300">
                {encryptionMethod === 'pake' ? 'Shared Password' : 'Password'}
              </Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-700/50 border-gray-600 text-white"
                placeholder="Enter encryption password"
              />
            </div>
          )}

          {/* File Selection */}
          <div className="space-y-2">
            <Label className="text-gray-300">Select File</Label>
            <Input
              type="file"
              onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              className="bg-gray-700/50 border-gray-600 text-white file:bg-primary file:text-black"
            />
          </div>

          {/* Options */}
          <div className="space-y-3 p-4 bg-gray-700/20 rounded-lg">
            <h4 className="font-semibold text-gray-300">Advanced Options</h4>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="sign" 
                checked={signFile} 
                onCheckedChange={setSignFile}
                className="border-gray-500"
              />
              <Label htmlFor="sign" className="text-sm text-gray-300 flex items-center">
                <FileSignature className="w-4 h-4 mr-1" />
                Sign file (Dilithium)
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox 
                id="shred" 
                checked={shredOriginal} 
                onCheckedChange={setShredOriginal}
                className="border-gray-500"
              />
              <Label htmlFor="shred" className="text-sm text-gray-300 flex items-center">
                <Trash2 className="w-4 h-4 mr-1" />
                Shred original file
              </Label>
            </div>

            {shredOriginal && (
              <div className="ml-6 space-y-2">
                <Label className="text-xs text-gray-400">Shred Passes</Label>
                <Select value={shredPasses.toString()} onValueChange={(value) => setShredPasses(parseInt(value))}>
                  <SelectTrigger className="bg-gray-600/50 border-gray-500 h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="1">Simple (1 pass)</SelectItem>
                    <SelectItem value="3">DoD (3 passes)</SelectItem>
                    <SelectItem value="7">DoD Extended (7 passes)</SelectItem>
                    <SelectItem value="35">Gutmann (35 passes)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <Button 
            onClick={() => encryptMutation.mutate()}
            disabled={!selectedFile || encryptMutation.isPending}
            className="w-full bg-primary hover:bg-primary/80"
          >
            {encryptMutation.isPending ? 'Encrypting...' : 'Encrypt File'}
          </Button>
        </TabsContent>

        <TabsContent value="decrypt" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Decryption Method Detection */}
            <div className="space-y-2">
              <Label className="text-gray-300">Decryption Method</Label>
              <div className="p-3 bg-gray-700/20 rounded-lg">
                <Badge variant="secondary" className="text-xs">
                  Auto-detected from file
                </Badge>
              </div>
            </div>

            {/* File Selection */}
            <div className="space-y-2">
              <Label className="text-gray-300">Encrypted File</Label>
              <Input
                type="file"
                accept=".encrypted"
                onChange={(e) => setDecryptFile(e.target.files?.[0] || null)}
                className="bg-gray-700/50 border-gray-600 text-white file:bg-primary file:text-black"
              />
            </div>
          </div>

          {/* Decryption Inputs */}
          <div className="space-y-4 p-4 bg-gray-700/20 rounded-lg">
            <h4 className="font-semibold text-gray-300">Decryption Keys</h4>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Password (for AES/PAKE)</Label>
              <Input
                type="password"
                className="bg-gray-700/50 border-gray-600 text-white"
                placeholder="Enter decryption password"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Private Key (for Kyber/Hybrid)</Label>
              <Input
                type="file"
                accept=".key"
                className="bg-gray-700/50 border-gray-600 text-white file:bg-primary file:text-black"
              />
            </div>
          </div>

          <Button 
            onClick={() => decryptMutation.mutate()}
            disabled={!decryptFile || decryptMutation.isPending}
            className="w-full bg-primary hover:bg-primary/80"
          >
            {decryptMutation.isPending ? 'Decrypting...' : 'Decrypt File'}
          </Button>
        </TabsContent>
      </Tabs>

      {/* Encryption Flows Info */}
      <div className="mt-6 p-4 bg-gray-700/10 rounded-lg">
        <h4 className="font-semibold text-gray-300 mb-2">📋 Encryption Flows</h4>
        <div className="text-xs text-gray-400 space-y-1">
          <div><strong>AES:</strong> Password → AES-256-GCM → file + IV + salt</div>
          <div><strong>Kyber:</strong> Generate keypair → encrypt small secret</div>
          <div><strong>Hybrid:</strong> AES-256-GCM + Kyber-wrapped password</div>
          <div><strong>PAKE:</strong> Shared password → PAKE → AES key → encrypt</div>
        </div>
      </div>
    </div>
  );
}
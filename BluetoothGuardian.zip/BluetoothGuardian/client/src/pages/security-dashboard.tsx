import { useState } from 'react';
import { BackupTimer } from '@/components/backup-timer';
import { BackupHistory } from '@/components/backup-history';
import { SecurityToggle } from '@/components/security-toggle';
import { FileEncryption } from '@/components/file-encryption';
import { LocationSpoofer } from '@/components/location-spoofer';
import { AndroidBackup } from '@/components/android-backup';
import { EncryptionSuite } from '@/components/encryption-suite';
import { ConfirmationDialog } from '@/components/ui/confirmation-dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Bluetooth, 
  Key, 
  MapPin, 
  Settings, 
  ChevronDown, 
  RefreshCw,
  Shield
} from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { SecuritySettings } from '@shared/schema';

export default function SecurityDashboard() {
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [isLocationOpen, setIsLocationOpen] = useState(false);
  const [isFileEncryptionOpen, setIsFileEncryptionOpen] = useState(false);
  const [isAndroidBackupOpen, setIsAndroidBackupOpen] = useState(false);
  const [isEncryptionSuiteOpen, setIsEncryptionSuiteOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings } = useQuery<SecuritySettings>({
    queryKey: ['/api/security-settings']
  });

  const updateSettingsMutation = useMutation({
    mutationFn: (newSettings: Partial<SecuritySettings>) => 
      apiRequest('PATCH', '/api/security-settings', newSettings),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update security settings. Please try again.",
        variant: "destructive",
      });
    }
  });

  const resetMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/reset'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/backup-history'] });
      toast({
        title: "Settings Reset",
        description: "All security settings have been reset to defaults.",
      });
    },
    onError: () => {
      toast({
        title: "Reset Failed",
        description: "Failed to reset settings. Please try again.",
        variant: "destructive",
      });
    }
  });

  const generateKeysMutation = useMutation({
    mutationFn: (keyType: string) => apiRequest('POST', '/api/crypto/generate-keys', { keyType }),
    onSuccess: () => {
      toast({
        title: "Keys Generated",
        description: "New cryptographic keys have been generated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate cryptographic keys. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleToggle = (setting: keyof SecuritySettings, value: boolean) => {
    updateSettingsMutation.mutate({ [setting]: value });
  };

  if (!settings) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading security dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background text-white">
      {/* Header */}
      <header className="px-4 py-6 text-center border-b border-gray-700">
        <h1 className="text-2xl font-bold text-white mb-2">
          <Shield className="inline w-6 h-6 text-primary mr-2" />
          SecureGuard
        </h1>
        <div className="flex items-center justify-center space-x-2">
          <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-300">Secure Connection</span>
        </div>
      </header>

      {/* Backup Timer */}
      <BackupTimer 
        onViewMoreToggle={() => setIsHistoryOpen(!isHistoryOpen)}
        isViewMoreOpen={isHistoryOpen}
      />

      {/* Android Backup Option */}
      <section className="px-4">
        <Button 
          onClick={() => setIsAndroidBackupOpen(!isAndroidBackupOpen)}
          className="w-full bg-surface rounded-xl p-4 shadow-lg flex items-center justify-between hover:bg-gray-700/50"
          variant="ghost"
        >
          <div className="flex items-center">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center mr-3">
              <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.6,11.48 L19.44,8.3 C20.06,7.08 19.6,5.59 18.38,4.97 C17.16,4.35 15.67,4.81 15.05,6.03 L13.21,9.21 C13.21,9.21 14.27,8.84 15.77,9.26 C17.27,9.68 17.6,11.48 17.6,11.48 M15.5,13.82 L16.17,15.55 C16.65,16.85 15.9,18.3 14.6,18.78 C13.3,19.26 11.85,18.51 11.37,17.21 L10.7,15.47 C10.7,15.47 11.76,15.28 13.11,14.31 C14.46,13.34 15.5,13.82 15.5,13.82 M9.7,9.21 C10.5,6.89 9.4,4.25 7.07,3.5 C4.74,2.74 2.1,3.84 1.35,6.17 C0.59,8.5 1.69,11.14 4.02,11.89 C6.35,12.65 8.95,11.54 9.7,9.21 M9.7,9.21 L8.67,11.61 L6.26,10.67 L7.3,8.27 C7.3,8.27 8.48,8.63 9.7,9.21 Z"/>
              </svg>
            </div>
            <span className="font-semibold text-white">Android Data Backup</span>
          </div>
          <ChevronDown 
            className={`text-gray-400 transition-transform duration-200 w-5 h-5 ${
              isAndroidBackupOpen ? 'rotate-180' : ''
            }`} 
          />
        </Button>
      </section>

      {/* Android Backup */}
      {isAndroidBackupOpen && (
        <section className="px-4 pb-8 animate-slide-down">
          <AndroidBackup />
        </section>
      )}

      {/* Backup History */}
      <BackupHistory isOpen={isHistoryOpen} />

      {/* Security Toggles Grid */}
      <section className="px-4 py-6">
        <h2 className="text-lg font-semibold mb-4 text-gray-200">Security Features</h2>
        
        <div className="grid grid-cols-2 gap-4">
          <SecurityToggle
            icon={Bluetooth}
            title="Bluetooth"
            description="Auto-disable when idle"
            enabled={settings.bluetoothEnabled!}
            onToggle={(enabled) => handleToggle('bluetoothEnabled', enabled)}
            color="#1565C0"
            status="Protected"
          />

          <div className="bg-surface rounded-xl p-4 shadow-lg ring-2 ring-warning/20">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-warning/20">
                <Key className="w-5 h-5 text-warning" />
              </div>
              <div className="w-6 h-3 bg-warning rounded-full"></div>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-white text-sm">Quantum Encryption</h3>
              <p className="text-xs text-gray-400">Always enabled by default</p>
              <Badge variant="secondary" className="bg-warning/20 text-warning text-xs px-2 py-1">
                Quantum Safe
              </Badge>
            </div>
          </div>

          <div 
            className="bg-surface rounded-xl p-4 shadow-lg cursor-pointer transition-all duration-200 hover:scale-105"
            onClick={() => setIsLocationOpen(!isLocationOpen)}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-green-500/20">
                <MapPin className="w-5 h-5 text-green-500" />
              </div>
              <div className="text-right">
                <ChevronDown 
                  className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${
                    isLocationOpen ? 'rotate-180' : ''
                  }`} 
                />
              </div>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-white text-sm">Location Privacy</h3>
              <p className="text-xs text-gray-400">Mock location control</p>
              <div className="text-xs text-green-400 font-mono">
                {settings?.mockLatitude}, {settings?.mockLongitude}
              </div>
            </div>
          </div>

          <div 
            className="bg-surface rounded-xl p-4 shadow-lg cursor-pointer transition-all duration-200 hover:scale-105"
            onClick={() => setIsFileEncryptionOpen(!isFileEncryptionOpen)}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-warning/20">
                <Key className="w-5 h-5 text-warning" />
              </div>
              <div className="text-right">
                <ChevronDown 
                  className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${
                    isFileEncryptionOpen ? 'rotate-180' : ''
                  }`} 
                />
              </div>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-white text-sm">File Encryption</h3>
              <p className="text-xs text-gray-400">Kyber file protection</p>
              <div className="text-xs text-warning">
                Post-quantum crypto
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Location Spoofer */}
      <LocationSpoofer isOpen={isLocationOpen} />

      {/* File Encryption */}
      {isFileEncryptionOpen && (
        <section className="px-4 pb-8 animate-slide-down">
          <FileEncryption />
        </section>
      )}

      {/* Advanced Options */}
      <section className="px-4 pb-8">
        <Button 
          onClick={() => setIsAdvancedOpen(!isAdvancedOpen)}
          className="w-full bg-surface rounded-xl p-4 shadow-lg flex items-center justify-between hover:bg-gray-700/50"
          variant="ghost"
        >
          <div className="flex items-center">
            <Settings className="text-primary mr-3 w-5 h-5" />
            <span className="font-semibold text-white">Advanced Options</span>
          </div>
          <ChevronDown 
            className={`text-gray-400 transition-transform duration-200 w-5 h-5 ${
              isAdvancedOpen ? 'rotate-180' : ''
            }`} 
          />
        </Button>

        {isAdvancedOpen && (
          <div className="mt-4 space-y-4 animate-slide-down">
            {/* Key Management */}
            <div className="bg-surface border border-gray-700 rounded-xl p-4">
              <h4 className="font-medium text-white mb-3">Cryptographic Keys</h4>
              <div className="space-y-3">
                <Button
                  onClick={() => generateKeysMutation.mutate('kyber')}
                  disabled={generateKeysMutation.isPending}
                  className="w-full text-left p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors justify-start"
                  variant="ghost"
                >
                  <div className="flex items-center justify-between w-full">
                    <div>
                      <div className="font-medium text-sm text-white">Regenerate Keys</div>
                      <div className="text-xs text-gray-400">Generate new Kyber key pairs</div>
                    </div>
                    <Key className="text-primary w-4 h-4" />
                  </div>
                </Button>
                
                <Button
                  className="w-full text-left p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors justify-start"
                  variant="ghost"
                >
                  <div className="flex items-center justify-between w-full">
                    <div>
                      <div className="font-medium text-sm text-white">Export Backup Keys</div>
                      <div className="text-xs text-gray-400">Secure key backup export</div>
                    </div>
                    <svg className="text-secondary w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                    </svg>
                  </div>
                </Button>
              </div>
            </div>

            {/* Security Settings */}
            <div className="bg-surface border border-gray-700 rounded-xl p-4">
              <h4 className="font-medium text-white mb-3">Security Preferences</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Auto-backup interval</span>
                  <Select defaultValue="6">
                    <SelectTrigger className="w-24 bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      <SelectItem value="1">1 hour</SelectItem>
                      <SelectItem value="6">6 hours</SelectItem>
                      <SelectItem value="12">12 hours</SelectItem>
                      <SelectItem value="24">24 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Encryption strength</span>
                  <Select defaultValue="kyber-768">
                    <SelectTrigger className="w-32 bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      <SelectItem value="kyber-512">Kyber-512</SelectItem>
                      <SelectItem value="kyber-768">Kyber-768</SelectItem>
                      <SelectItem value="kyber-1024">Kyber-1024</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Reset Section */}
            <div className="bg-surface border border-red-600/30 rounded-xl p-4">
              <h4 className="font-medium text-accent mb-3">Danger Zone</h4>
              <ConfirmationDialog
                title="Reset All Settings"
                description="This will reset all security settings and clear backup history. This action cannot be undone."
                onConfirm={() => resetMutation.mutate()}
                destructive
                confirmText="Reset"
                trigger={
                  <Button
                    disabled={resetMutation.isPending}
                    className="w-full bg-red-500/10 hover:bg-red-500/20 text-accent font-medium py-3 px-4 border border-red-600/30 transition-colors duration-200"
                    variant="outline"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Reset All Settings
                  </Button>
                }
              />
            </div>
          </div>
        )}
      </section>

      {/* Security Status */}
      <section className="px-4 pb-8">
        <div className="bg-surface rounded-xl shadow-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-white">Security Status</h3>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-secondary rounded-full"></div>
              <span className="text-sm text-secondary font-medium">Secure</span>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Last Security Scan</span>
              <span className="text-sm text-gray-400">2 minutes ago</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Threats Blocked Today</span>
              <Badge variant="secondary" className="bg-secondary/20 text-secondary">7</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Security Score</span>
              <div className="flex items-center space-x-2">
                <div className="w-16 h-2 bg-gray-600 rounded-full">
                  <div className="w-14 h-2 bg-secondary rounded-full"></div>
                </div>
                <span className="text-sm font-medium text-secondary">87%</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

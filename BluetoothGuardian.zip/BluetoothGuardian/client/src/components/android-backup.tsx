import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { 
  Smartphone, 
  Users, 
  MessageSquare, 
  Phone, 
  Download, 
  Image, 
  Music, 
  FileText, 
  Calendar, 
  Globe,
  Shield,
  Wifi,
  Bell,
  Terminal
} from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { BackupHistory } from '@shared/schema';

interface BackupItem {
  id: string;
  name: string;
  description: string;
  icon: any;
  fileType: string;
  estimatedSize: string;
  requiresRoot?: boolean;
  enabled: boolean;
}

export function AndroidBackup() {
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [currentBackupItem, setCurrentBackupItem] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [backupItems, setBackupItems] = useState<BackupItem[]>([
    {
      id: 'contacts',
      name: 'Contacts',
      description: 'All contact information',
      icon: Users,
      fileType: 'CSV',
      estimatedSize: '2.5 MB',
      enabled: true
    },
    {
      id: 'sms',
      name: 'SMS Messages',
      description: 'Text message history',
      icon: MessageSquare,
      fileType: 'JSON',
      estimatedSize: '15.2 MB',
      enabled: true
    },
    {
      id: 'call_logs',
      name: 'Call Logs',
      description: 'Call history and duration',
      icon: Phone,
      fileType: 'CSV',
      estimatedSize: '1.8 MB',
      enabled: true
    },
    {
      id: 'apps_list',
      name: 'Installed Apps',
      description: 'List of installed applications',
      icon: Download,
      fileType: 'JSON',
      estimatedSize: '0.5 MB',
      enabled: true
    },
    {
      id: 'photos_metadata',
      name: 'Photos Metadata',
      description: 'Photo information (no images)',
      icon: Image,
      fileType: 'JSON',
      estimatedSize: '8.9 MB',
      enabled: false
    },
    {
      id: 'audio_metadata',
      name: 'Audio Metadata',
      description: 'Music file information',
      icon: Music,
      fileType: 'CSV',
      estimatedSize: '2.1 MB',
      enabled: false
    },
    {
      id: 'documents',
      name: 'Documents List',
      description: 'File metadata or archive',
      icon: FileText,
      fileType: 'ZIP',
      estimatedSize: '12.4 MB',
      enabled: false
    },
    {
      id: 'calendar',
      name: 'Calendar Events',
      description: 'Calendar appointments',
      icon: Calendar,
      fileType: 'ICS',
      estimatedSize: '0.8 MB',
      enabled: true
    },
    {
      id: 'browser_history',
      name: 'Browser History',
      description: 'Web browsing history',
      icon: Globe,
      fileType: 'JSON',
      estimatedSize: '4.2 MB',
      enabled: false
    },
    // Root access required items
    {
      id: 'app_data',
      name: 'App Data',
      description: 'Application private data',
      icon: Shield,
      fileType: 'TAR',
      estimatedSize: '45.7 MB',
      requiresRoot: true,
      enabled: false
    },
    {
      id: 'wifi_passwords',
      name: 'Wi-Fi Passwords',
      description: 'Saved network credentials',
      icon: Wifi,
      fileType: 'TXT',
      estimatedSize: '0.1 MB',
      requiresRoot: true,
      enabled: false
    },
    {
      id: 'notification_logs',
      name: 'Notification Logs',
      description: 'System notification history',
      icon: Bell,
      fileType: 'JSON',
      estimatedSize: '3.6 MB',
      requiresRoot: true,
      enabled: false
    },
    {
      id: 'system_logs',
      name: 'System Logs',
      description: 'Device system logs',
      icon: Terminal,
      fileType: 'LOG',
      estimatedSize: '8.1 MB',
      requiresRoot: true,
      enabled: false
    }
  ]);

  const { data: backupHistory = [] } = useQuery<BackupHistory[]>({
    queryKey: ['/api/backup-history']
  });

  const backupMutation = useMutation({
    mutationFn: async () => {
      setIsBackingUp(true);
      setBackupProgress(0);
      
      const enabledItems = backupItems.filter(item => item.enabled);
      let totalSize = 0;
      let totalItems = 0;

      for (let i = 0; i < enabledItems.length; i++) {
        const item = enabledItems[i];
        setCurrentBackupItem(item.name);
        setBackupProgress((i / enabledItems.length) * 100);
        
        // Simulate backup time
        await new Promise(resolve => setTimeout(resolve, 800));
        
        totalSize += parseFloat(item.estimatedSize.replace(' MB', ''));
        totalItems += Math.floor(Math.random() * 1000) + 100;
      }

      setBackupProgress(100);
      setCurrentBackupItem('Encrypting with Kyber...');
      
      // Simulate encryption
      await new Promise(resolve => setTimeout(resolve, 1500));

      return apiRequest('POST', '/api/backup', {
        backupType: 'android_data',
        encryptedData: `kyber_encrypted_android_data_${Date.now()}`,
        size: `${totalSize.toFixed(1)} MB`,
        itemCount: totalItems
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/backup-history'] });
      toast({
        title: "Android Backup Complete",
        description: "Your Android data has been encrypted and backed up securely with Kyber.",
      });
    },
    onError: () => {
      toast({
        title: "Backup Failed",
        description: "Failed to create Android data backup. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsBackingUp(false);
      setBackupProgress(0);
      setCurrentBackupItem('');
    }
  });

  const toggleItem = (itemId: string) => {
    setBackupItems(prev => prev.map(item => 
      item.id === itemId ? { ...item, enabled: !item.enabled } : item
    ));
  };

  const startBackup = () => {
    const enabledItems = backupItems.filter(item => item.enabled);
    if (enabledItems.length === 0) {
      toast({
        title: "No Items Selected",
        description: "Please select at least one item to backup.",
        variant: "destructive",
      });
      return;
    }
    
    backupMutation.mutate();
  };

  const enabledCount = backupItems.filter(item => item.enabled).length;
  const totalEstimatedSize = backupItems
    .filter(item => item.enabled)
    .reduce((sum, item) => sum + parseFloat(item.estimatedSize.replace(' MB', '')), 0);

  return (
    <div className="space-y-6">
      {/* Backup Control */}
      <Card className="bg-surface border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Smartphone className="w-5 h-5 mr-2 text-primary" />
            Android Data Backup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
            <div>
              <p className="text-white font-medium">Selected Items: {enabledCount}</p>
              <p className="text-gray-400 text-sm">
                Estimated Size: {totalEstimatedSize.toFixed(1)} MB
              </p>
            </div>
            <Button
              onClick={startBackup}
              disabled={isBackingUp || enabledCount === 0}
              className="bg-primary hover:bg-blue-700 text-white font-semibold px-6"
            >
              {isBackingUp ? 'Backing Up...' : 'Start Backup'}
            </Button>
          </div>

          {isBackingUp && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300">{currentBackupItem}</span>
                <span className="text-gray-400">{Math.round(backupProgress)}%</span>
              </div>
              <Progress value={backupProgress} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Backup Items */}
      <Card className="bg-surface border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Data Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {/* Standard Access Items */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-gray-300">Standard Access</h4>
              {backupItems.filter(item => !item.requiresRoot).map((item) => {
                const IconComponent = item.icon;
                return (
                  <div key={item.id} className="flex items-center space-x-3 p-3 bg-gray-700/30 rounded-lg">
                    <Checkbox
                      checked={item.enabled}
                      onCheckedChange={() => toggleItem(item.id)}
                      className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                    />
                    <IconComponent className="w-5 h-5 text-primary" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-white font-medium">{item.name}</p>
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary" className="bg-gray-600 text-gray-200 text-xs">
                            {item.fileType}
                          </Badge>
                          <span className="text-xs text-gray-400">{item.estimatedSize}</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Root Access Items */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-gray-300 flex items-center">
                Root Access Required
                <Badge variant="destructive" className="ml-2 text-xs">Advanced</Badge>
              </h4>
              {backupItems.filter(item => item.requiresRoot).map((item) => {
                const IconComponent = item.icon;
                return (
                  <div key={item.id} className="flex items-center space-x-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                    <Checkbox
                      checked={item.enabled}
                      onCheckedChange={() => toggleItem(item.id)}
                      className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                    />
                    <IconComponent className="w-5 h-5 text-red-400" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-white font-medium">{item.name}</p>
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary" className="bg-gray-600 text-gray-200 text-xs">
                            {item.fileType}
                          </Badge>
                          <span className="text-xs text-gray-400">{item.estimatedSize}</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <Card className="bg-surface border-blue-500/30">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 text-blue-400 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-300 mb-2">Encryption Always Enabled</h4>
              <p className="text-sm text-gray-300">
                All backup data is automatically encrypted using Kyber post-quantum cryptography. 
                Your data remains secure even against future quantum computing threats.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
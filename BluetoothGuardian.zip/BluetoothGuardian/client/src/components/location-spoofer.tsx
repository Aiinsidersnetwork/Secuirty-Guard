import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Globe, Copy } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { SecuritySettings } from '@shared/schema';

interface LocationSpooferProps {
  isOpen: boolean;
}

export function LocationSpoofer({ isOpen }: LocationSpooferProps) {
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings } = useQuery<SecuritySettings>({
    queryKey: ['/api/security-settings']
  });

  const updateLocationMutation = useMutation({
    mutationFn: ({ lat, lng }: { lat: string; lng: string }) => 
      apiRequest('PATCH', '/api/location', { latitude: lat, longitude: lng }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
      setLatitude('');
      setLongitude('');
      toast({
        title: "Location Updated",
        description: "Mock location coordinates have been set for developer mode.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update location coordinates. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleUpdateLocation = () => {
    if (!latitude || !longitude) {
      toast({
        title: "Invalid Coordinates",
        description: "Please enter both latitude and longitude values.",
        variant: "destructive",
      });
      return;
    }

    // Validate coordinate ranges
    const lat = parseFloat(latitude);
    const lng = parseFloat(longitude);
    
    if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      toast({
        title: "Invalid Coordinates",
        description: "Latitude must be between -90 and 90, longitude between -180 and 180.",
        variant: "destructive",
      });
      return;
    }

    updateLocationMutation.mutate({ lat: latitude, lng: longitude });
  };

  const copyCurrentCoordinates = () => {
    if (settings?.mockLatitude && settings?.mockLongitude) {
      const coords = `${settings.mockLatitude}, ${settings.mockLongitude}`;
      navigator.clipboard.writeText(coords);
      toast({
        title: "Coordinates Copied",
        description: "Current mock coordinates copied to clipboard.",
      });
    }
  };

  const presetLocations = [
    { name: "San Francisco, CA", lat: "37.7749", lng: "-122.4194" },
    { name: "New York, NY", lat: "40.7128", lng: "-74.0060" },
    { name: "London, UK", lat: "51.5074", lng: "-0.1278" },
    { name: "Tokyo, Japan", lat: "35.6762", lng: "139.6503" },
    { name: "Sydney, Australia", lat: "-33.8688", lng: "151.2093" },
    { name: "Berlin, Germany", lat: "52.5200", lng: "13.4050" }
  ];

  const setPresetLocation = (lat: string, lng: string) => {
    setLatitude(lat);
    setLongitude(lng);
  };

  if (!isOpen) return null;

  return (
    <section className="px-4 pb-8 animate-slide-down">
      <Card className="bg-surface border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Navigation className="w-5 h-5 mr-2 text-primary" />
            Location Privacy Control
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Current Mock Location */}
          <div className="p-4 bg-gray-700/30 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-white">Current Mock Location</h4>
              <Badge variant="secondary" className="bg-secondary/20 text-secondary">
                Developer Mode
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-white font-mono text-sm">
                    {settings?.mockLatitude}, {settings?.mockLongitude}
                  </p>
                  <p className="text-gray-400 text-xs">
                    Latitude, Longitude
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyCurrentCoordinates}
                className="text-gray-400 hover:text-white"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Manual Coordinate Entry */}
          <div className="space-y-4">
            <h4 className="font-medium text-white">Set Custom Coordinates</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="latitude" className="text-gray-300">Latitude</Label>
                <Input
                  id="latitude"
                  type="number"
                  step="any"
                  placeholder="37.7749"
                  value={latitude}
                  onChange={(e) => setLatitude(e.target.value)}
                  className="mt-1 bg-gray-700 border-gray-600 text-white"
                />
                <p className="text-xs text-gray-500 mt-1">-90 to 90</p>
              </div>
              <div>
                <Label htmlFor="longitude" className="text-gray-300">Longitude</Label>
                <Input
                  id="longitude"
                  type="number"
                  step="any"
                  placeholder="-122.4194"
                  value={longitude}
                  onChange={(e) => setLongitude(e.target.value)}
                  className="mt-1 bg-gray-700 border-gray-600 text-white"
                />
                <p className="text-xs text-gray-500 mt-1">-180 to 180</p>
              </div>
            </div>
            <Button
              onClick={handleUpdateLocation}
              disabled={updateLocationMutation.isPending}
              className="w-full bg-primary hover:bg-blue-700 text-white"
            >
              {updateLocationMutation.isPending ? 'Updating...' : 'Update Mock Location'}
            </Button>
          </div>

          {/* Preset Locations */}
          <div className="space-y-3">
            <h4 className="font-medium text-white">Quick Presets</h4>
            <div className="grid grid-cols-1 gap-2">
              {presetLocations.map((location) => (
                <Button
                  key={location.name}
                  variant="ghost"
                  onClick={() => setPresetLocation(location.lat, location.lng)}
                  className="justify-between p-3 bg-gray-700/30 hover:bg-gray-700/50 text-left h-auto"
                >
                  <div>
                    <p className="text-white font-medium">{location.name}</p>
                    <p className="text-gray-400 text-xs font-mono">
                      {location.lat}, {location.lng}
                    </p>
                  </div>
                  <Globe className="w-4 h-4 text-gray-400" />
                </Button>
              ))}
            </div>
          </div>

          {/* Developer Instructions */}
          <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <h4 className="font-medium text-blue-300 mb-2 flex items-center">
              <Navigation className="w-4 h-4 mr-2" />
              Android Developer Mode Setup
            </h4>
            <div className="text-sm text-gray-300 space-y-2">
              <p>1. Enable Developer Options in Android Settings</p>
              <p>2. Turn on "Allow mock locations"</p>
              <p>3. Install a mock location app</p>
              <p>4. Use the coordinates from this app</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
import { 
  users, 
  securitySettings, 
  backupHistory, 
  encryptedFiles,
  cryptographicKeys,
  type User, 
  type InsertUser,
  type SecuritySettings,
  type InsertSecuritySettings,
  type BackupHistory,
  type InsertBackupHistory,
  type EncryptedFiles,
  type InsertEncryptedFiles,
  type CryptographicKeys,
  type InsertCryptographicKeys
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getSecuritySettings(userId: number): Promise<SecuritySettings | undefined>;
  updateSecuritySettings(userId: number, settings: Partial<InsertSecuritySettings>): Promise<SecuritySettings>;
  
  getBackupHistory(userId: number): Promise<BackupHistory[]>;
  createBackupEntry(userId: number, backup: InsertBackupHistory): Promise<BackupHistory>;
  deleteBackupEntry(userId: number, backupId: number): Promise<boolean>;
  clearBackupHistory(userId: number): Promise<boolean>;
  
  getEncryptedFiles(userId: number): Promise<EncryptedFiles[]>;
  createEncryptedFile(userId: number, file: InsertEncryptedFiles): Promise<EncryptedFiles>;
  deleteEncryptedFile(userId: number, fileId: number): Promise<boolean>;
  
  getCryptographicKeys(userId: number, keyType?: string): Promise<CryptographicKeys[]>;
  createCryptographicKey(userId: number, key: InsertCryptographicKeys): Promise<CryptographicKeys>;
  deleteCryptographicKey(userId: number, keyId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private securitySettings: Map<number, SecuritySettings>;
  private backupHistory: Map<number, BackupHistory[]>;
  private encryptedFiles: Map<number, EncryptedFiles[]>;
  private cryptographicKeys: Map<number, CryptographicKeys[]>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.securitySettings = new Map();
    this.backupHistory = new Map();
    this.encryptedFiles = new Map();
    this.cryptographicKeys = new Map();
    this.currentId = 1;
    
    // Initialize default user and settings for demo
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    const defaultUser: User = {
      id: 1,
      username: "secureuser",
      password: "hashedpassword"
    };
    
    const defaultSettings: SecuritySettings = {
      id: 1,
      userId: 1,
      bluetoothEnabled: true,
      quantumEncryptionEnabled: true, // Always enabled by default
      locationPrivacyEnabled: true,
      mockLatitude: "37.7749",
      mockLongitude: "-122.4194",
      lastBackupTime: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
    };

    this.users.set(1, defaultUser);
    this.securitySettings.set(1, defaultSettings);
    this.backupHistory.set(1, []);
    this.encryptedFiles.set(1, []);
    this.cryptographicKeys.set(1, []);
    this.currentId = 2;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    
    // Initialize default security settings for new user
    const defaultSettings: SecuritySettings = {
      id: this.currentId++,
      userId: id,
      bluetoothEnabled: true,
      quantumEncryptionEnabled: true, // Always enabled by default
      locationPrivacyEnabled: true,
      mockLatitude: "37.7749",
      mockLongitude: "-122.4194",
      lastBackupTime: new Date()
    };
    
    this.securitySettings.set(id, defaultSettings);
    this.backupHistory.set(id, []);
    this.encryptedFiles.set(id, []);
    this.cryptographicKeys.set(id, []);
    
    return user;
  }

  async getSecuritySettings(userId: number): Promise<SecuritySettings | undefined> {
    return this.securitySettings.get(userId);
  }

  async updateSecuritySettings(userId: number, settings: Partial<InsertSecuritySettings>): Promise<SecuritySettings> {
    const existing = this.securitySettings.get(userId);
    if (!existing) {
      throw new Error("Security settings not found");
    }
    
    const updated: SecuritySettings = {
      ...existing,
      ...settings,
      lastBackupTime: settings.lastBackupTime || existing.lastBackupTime
    };
    
    this.securitySettings.set(userId, updated);
    return updated;
  }

  async getBackupHistory(userId: number): Promise<BackupHistory[]> {
    return this.backupHistory.get(userId) || [];
  }

  async createBackupEntry(userId: number, backup: InsertBackupHistory): Promise<BackupHistory> {
    const userBackups = this.backupHistory.get(userId) || [];
    const id = this.currentId++;
    
    const newBackup: BackupHistory = {
      id,
      userId,
      timestamp: new Date(),
      backupType: backup.backupType || "manual",
      encryptedData: backup.encryptedData || null,
      size: backup.size || null,
      itemCount: backup.itemCount || null,
      encryptionMethod: backup.encryptionMethod || null
    };
    
    userBackups.unshift(newBackup); // Add to beginning
    this.backupHistory.set(userId, userBackups);
    
    return newBackup;
  }

  async deleteBackupEntry(userId: number, backupId: number): Promise<boolean> {
    const userBackups = this.backupHistory.get(userId) || [];
    const filteredBackups = userBackups.filter(backup => backup.id !== backupId);
    
    if (filteredBackups.length === userBackups.length) {
      return false; // No backup was deleted
    }
    
    this.backupHistory.set(userId, filteredBackups);
    return true;
  }

  async clearBackupHistory(userId: number): Promise<boolean> {
    this.backupHistory.set(userId, []);
    return true;
  }

  async getCryptographicKeys(userId: number, keyType?: string): Promise<CryptographicKeys[]> {
    const userKeys = this.cryptographicKeys.get(userId) || [];
    
    if (keyType) {
      return userKeys.filter(key => key.keyType === keyType);
    }
    
    return userKeys;
  }

  async createCryptographicKey(userId: number, key: InsertCryptographicKeys): Promise<CryptographicKeys> {
    const userKeys = this.cryptographicKeys.get(userId) || [];
    const id = this.currentId++;
    
    const newKey: CryptographicKeys = {
      id,
      userId,
      createdAt: new Date(),
      keyType: key.keyType!,
      publicKey: key.publicKey!,
      encryptedPrivateKey: key.encryptedPrivateKey!
    };
    
    userKeys.push(newKey);
    this.cryptographicKeys.set(userId, userKeys);
    
    return newKey;
  }

  async deleteCryptographicKey(userId: number, keyId: number): Promise<boolean> {
    const userKeys = this.cryptographicKeys.get(userId) || [];
    const filteredKeys = userKeys.filter(key => key.id !== keyId);
    
    if (filteredKeys.length === userKeys.length) {
      return false;
    }
    
    this.cryptographicKeys.set(userId, filteredKeys);
    return true;
  }

  async getEncryptedFiles(userId: number): Promise<EncryptedFiles[]> {
    return this.encryptedFiles.get(userId) || [];
  }

  async createEncryptedFile(userId: number, file: InsertEncryptedFiles): Promise<EncryptedFiles> {
    const userFiles = this.encryptedFiles.get(userId) || [];
    const id = this.currentId++;
    
    const newFile: EncryptedFiles = {
      id,
      userId,
      createdAt: new Date(),
      fileName: file.fileName!,
      originalSize: file.originalSize || null,
      encryptedData: file.encryptedData!,
      encryptionMethod: file.encryptionMethod || "Kyber-768"
    };
    
    userFiles.unshift(newFile); // Add to beginning
    this.encryptedFiles.set(userId, userFiles);
    
    return newFile;
  }

  async deleteEncryptedFile(userId: number, fileId: number): Promise<boolean> {
    const userFiles = this.encryptedFiles.get(userId) || [];
    const filteredFiles = userFiles.filter(file => file.id !== fileId);
    
    if (filteredFiles.length === userFiles.length) {
      return false;
    }
    
    this.encryptedFiles.set(userId, filteredFiles);
    return true;
  }
}

export const storage = new MemStorage();
